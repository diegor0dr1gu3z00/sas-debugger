repo: diegor0dr1gu3z00/sas-debugger
branch: main

## Last sync

date: 2026-09-07T21:45:00Z

### Updated in this project
- Built the `SAS Debugger` UI mockup (5 screens) on the real agent trace, oracle verdicts and 7-layer lineage.
- Field names, SQL and values lifted verbatim from `examples/app/agent.py` and the worked example.
- Eval numbers taken from the README results table (n = 268).

## Screen map

| Screen | Built from |
| --- | --- |
| Load (inputs, suspect cycles, captain note) | `examples/app/index.html`, `examples/app/agent.py` |
| Live run (streaming trace, agent loop) | `examples/app/agent.py`, `examples/app/server.py` |
| Localisation report | `examples/deep_debug_worked_example.md` |
| Lineage explorer (L0–L7) | `slm/lineage.py` |
| Model & eval | `README.md`, `eval/sft-bestofn.json` |
